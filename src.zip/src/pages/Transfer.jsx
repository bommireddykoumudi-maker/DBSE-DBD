import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";

function Transfer() {
  const navigate = useNavigate();

  const [accounts, setAccounts] = useState([]);
  const [fromAccount, setFromAccount] = useState("");
  const [toAccount, setToAccount] = useState("");
  const [amount, setAmount] = useState("");
  const [description, setDescription] = useState("");

  const [loading, setLoading] = useState(true);
  const [transferring, setTransferring] = useState(false);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");

  // Store fraud analysis result
  const [fraudResult, setFraudResult] = useState(null);

  // Load logged-in customer's accounts
  useEffect(() => {
    const fetchAccounts = async () => {
      const token = localStorage.getItem("access_token");
      const customerId = localStorage.getItem("customer_id");

      if (!token || !customerId) {
        navigate("/login");
        return;
      }

      try {
        const response = await fetch(
          `http://127.0.0.1:8000/dashboard/${customerId}`,
          {
            method: "GET",
            headers: {
              Authorization: `Bearer ${token}`,
            },
          }
        );

        const data = await response.json();

        if (!response.ok) {
          setError(data.detail || "Unable to load accounts");
          setLoading(false);
          return;
        }

        setAccounts(data.accounts);

        if (data.accounts.length > 0) {
          setFromAccount(String(data.accounts[0].account_id));
        }
      } catch (err) {
        setError("Unable to connect to the banking server.");
      }

      setLoading(false);
    };

    fetchAccounts();
  }, [navigate]);

  // Transfer money
  const handleTransfer = async (e) => {
    e.preventDefault();

    setMessage("");
    setError("");
    setFraudResult(null);

    if (!fromAccount) {
      setError("Please select a source account.");
      return;
    }

    if (!toAccount) {
      setError("Please enter recipient account ID.");
      return;
    }

    if (!amount || Number(amount) <= 0) {
      setError("Please enter a valid transfer amount.");
      return;
    }

    if (Number(fromAccount) === Number(toAccount)) {
      setError("Sender and receiver accounts cannot be the same.");
      return;
    }

    const token = localStorage.getItem("access_token");

    setTransferring(true);

    try {
      const response = await fetch(
        "http://127.0.0.1:8000/transfer",
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
          },
          body: JSON.stringify({
            from_account_id: Number(fromAccount),
            to_account_id: Number(toAccount),
            amount: Number(amount),
            description: description || null,
          }),
        }
      );

      const data = await response.json();

      if (!response.ok) {
        setError(data.detail || "Transfer failed");
        setTransferring(false);
        return;
      }

      setMessage(
        `Transfer successful! Transaction ID: ${data.transaction_id}`
      );

      // Save fraud analysis result
      setFraudResult(data.fraud_analysis);

      setToAccount("");
      setAmount("");
      setDescription("");

    } catch (err) {
      setError("Unable to connect to the banking server.");
    }

    setTransferring(false);
  };

  if (loading) {
    return (
      <div className="transfer-page">
        <div className="transfer-card">
          <h2>Loading accounts...</h2>
        </div>
      </div>
    );
  }

  return (
    <div className="transfer-page">

      <div className="transfer-card">

        <Link to="/dashboard" className="back-dashboard">
          ← Back to Dashboard
        </Link>

        <div className="transfer-header">

          <div className="transfer-icon">
            💸
          </div>

          <div>
            <h1>Transfer Money</h1>
            <p>
              Send money securely to another account
            </p>
          </div>

        </div>

        <form
          className="transfer-form"
          onSubmit={handleTransfer}
        >

          {/* FROM ACCOUNT */}

          <label>From Account</label>

          <select
            value={fromAccount}
            onChange={(e) => setFromAccount(e.target.value)}
          >

            <option value="">
              Select your account
            </option>

            {accounts.map((account) => (

              <option
                key={account.account_id}
                value={account.account_id}
              >
                {account.account_type} - ****{account.account_number} - ₹
                {Number(account.balance).toLocaleString("en-IN")}
              </option>

            ))}

          </select>


          {/* RECIPIENT */}

          <label>Recipient Account ID</label>

          <input
            type="number"
            placeholder="Enter recipient account ID"
            value={toAccount}
            onChange={(e) => setToAccount(e.target.value)}
          />


          {/* AMOUNT */}

          <label>Transfer Amount</label>

          <div className="amount-input">

            <span>₹</span>

            <input
              type="number"
              placeholder="Enter amount"
              min="1"
              step="0.01"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
            />

          </div>


          {/* DESCRIPTION */}

          <label>Description</label>

          <input
            type="text"
            placeholder="Enter transaction description"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
          />


          {/* ERROR */}

          {error && (
            <p className="transfer-error">
              ❌ {error}
            </p>
          )}


          {/* SUCCESS */}

          {message && (
            <p className="transfer-success">
              ✅ {message}
            </p>
          )}


          <button
            type="submit"
            className="transfer-btn"
            disabled={transferring}
          >
            {transferring
              ? "Processing Transfer..."
              : "Continue Transfer"}
          </button>

        </form>


        {/* =========================
            FRAUD ANALYSIS RESULT
           ========================= */}

        {fraudResult && (
          <div className="fraud-result-card">

            <div className="fraud-result-header">
              <div className="fraud-result-icon">
                🛡️
              </div>

              <div>
                <h2>Fraud Risk Analysis</h2>
                <p>
                  DBSCAN analysis completed successfully
                </p>
              </div>
            </div>


            <div className="fraud-result-grid">

              {/* Risk Score */}

              <div className="fraud-result-item">
                <span>Risk Score</span>
                <strong>
                  {fraudResult.risk_score}/100
                </strong>
              </div>


              {/* Risk Level */}

              <div className="fraud-result-item">
                <span>Risk Level</span>

                <strong
                  className={
                    fraudResult.risk_level === "HIGH"
                      ? "risk-high-text"
                      : fraudResult.risk_level === "REVIEW"
                      ? "risk-review-text"
                      : "risk-low-text"
                  }
                >
                  {fraudResult.risk_level}
                </strong>
              </div>


              {/* Cluster */}

              <div className="fraud-result-item">
                <span>DBSCAN Cluster</span>

                <strong>
                  {fraudResult.cluster_id}
                </strong>
              </div>


              {/* Anomaly */}

              <div className="fraud-result-item">
                <span>Anomaly Detected</span>

                <strong
                  className={
                    fraudResult.is_anomaly
                      ? "risk-high-text"
                      : "risk-low-text"
                  }
                >
                  {fraudResult.is_anomaly
                    ? "YES"
                    : "NO"}
                </strong>
              </div>

            </div>


            {/* Final security message */}

            <div className="fraud-result-message">

              {fraudResult.is_anomaly ? (
                <>
                  ⚠️ This transaction has been identified
                  as an unusual transaction pattern.
                </>
              ) : (
                <>
                  ✓ This transaction appears to follow
                  normal transaction patterns.
                </>
              )}

            </div>

          </div>
        )}


        {/* Fraud Detection Preview */}

        {!fraudResult && (
          <div className="fraud-preview">

            <div className="fraud-preview-icon">
              🛡️
            </div>

            <div>

              <h3>Fraud Risk Analysis</h3>

              <p>
                This transaction will be analyzed for
                suspicious patterns using our DBSCAN-based
                fraud detection system.
              </p>

              <span className="analysis-status">
                ✓ Security analysis enabled
              </span>

            </div>

          </div>
        )}

      </div>

    </div>
  );
}

export default Transfer;