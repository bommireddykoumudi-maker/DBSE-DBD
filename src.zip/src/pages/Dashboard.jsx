import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";

function Dashboard() {
  const navigate = useNavigate();

  const [dashboard, setDashboard] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    const fetchDashboard = async () => {
      const token = localStorage.getItem("access_token");
      const customerId = localStorage.getItem("customer_id");

      if (!token || !customerId) {
        navigate("/login");
        return;
      }

      try {
        const response = await fetch(
          `http://127.0.0.1:8000/dashboard/${customerId}`,
          {
            method: "GET",
            headers: {
              Authorization: `Bearer ${token}`,
            },
          }
        );

        const data = await response.json();

        if (!response.ok) {
          setError(data.detail || "Unable to load dashboard");
          setLoading(false);
          return;
        }

        setDashboard(data);

      } catch (error) {
        setError(
          "Unable to connect to the banking server."
        );
      }

      setLoading(false);
    };

    fetchDashboard();
  }, [navigate]);


  // Logout
  const handleLogout = () => {
    localStorage.removeItem("access_token");
    localStorage.removeItem("customer_id");
    localStorage.removeItem("user_id");
    localStorage.removeItem("email");

    navigate("/");
  };


  // Loading screen
  if (loading) {
    return (
      <div className="dashboard">
        <main className="dashboard-main">
          <h2>Loading dashboard...</h2>
        </main>
      </div>
    );
  }


  // Error
  if (error) {
    return (
      <div className="dashboard">
        <main className="dashboard-main">
          <h2>{error}</h2>
          <button onClick={() => navigate("/login")}>
            Back to Login
          </button>
        </main>
      </div>
    );
  }


  const customer = dashboard.customer;
  const accounts = dashboard.accounts;


  return (
    <div className="dashboard">

      {/* Sidebar */}
      <aside className="sidebar">

        <div className="dashboard-logo">
          🏦 EnterpriseBank
        </div>

        <nav className="sidebar-menu">

          <Link to="/dashboard" className="active">
            📊 Dashboard
          </Link>

          <a href="#accounts">
            🏦 Accounts
          </a>

          <Link to="/transfer">
            💸 Transfer Money
          </Link>

          <a href="#payments">
            💳 Payments
          </a>

          <a href="#transactions">
            📋 Transactions
          </a>

          <Link to="/fraud-detection">
            🛡️ Fraud Alerts
          </Link>

        </nav>

        <button
          className="logout"
          onClick={handleLogout}
        >
          ↪ Logout
        </button>

      </aside>


      {/* Main Content */}
      <main className="dashboard-main">

        {/* Header */}
        <header className="dashboard-header">

          <div>
            <h1>Dashboard</h1>

            <p>
              Welcome back, {customer.name} 👋
            </p>
          </div>

          <div className="profile">
            <span>👤</span>
            <strong>{customer.name}</strong>
          </div>

        </header>


        {/* Balance */}
        <section className="balance-card">

          <div>
            <p>Total Balance</p>

            <h2>
              ₹{dashboard.total_balance.toLocaleString("en-IN")}
            </h2>

            <span>Available balance</span>
          </div>

          <div className="balance-icon">
            💰
          </div>

        </section>


        {/* Account Cards */}
        <section
          className="account-section"
          id="accounts"
        >

          <h2>My Accounts</h2>

          <div className="account-cards">

            {accounts.map((account) => (

              <div
                className="account-card"
                key={account.account_id}
              >

                <div className="account-top">

                  <span>
                    {account.account_type === "SAVINGS"
                      ? "Savings Account"
                      : "Current Account"}
                  </span>

                  <span>
                    {account.account_type === "SAVINGS"
                      ? "💰"
                      : "🏦"}
                  </span>

                </div>

                <h3>
                  ₹{Number(account.balance).toLocaleString("en-IN")}
                </h3>

                <p>
                  **** **** {account.account_number}
                </p>

              </div>

            ))}

          </div>

        </section>


        {/* Quick Actions */}
        <section className="quick-actions">

          <h2>Quick Actions</h2>

          <div className="action-cards">

            <Link
              to="/transfer"
              className="action-link"
            >
              <button>
                💸
                <span>Transfer Money</span>
              </button>
            </Link>

            <button>
              💳
              <span>Make Payment</span>
            </button>

            <button>
              📋
              <span>View Transactions</span>
            </button>

          </div>

        </section>


        {/* Transactions */}
        <section
          className="transactions"
          id="transactions"
        >

          <div className="section-heading">

            <h2>Recent Transactions</h2>

            <a href="#transactions">
              View All
            </a>

          </div>

          <div className="transaction-list">

            <div className="transaction">

              <div className="transaction-icon deposit">
                ↓
              </div>

              <div className="transaction-info">

                <strong>
                  Salary Deposit
                </strong>

                <span>
                  08 Sep 2026
                </span>

              </div>

              <strong className="amount positive">
                +₹10,000
              </strong>

            </div>


            <div className="transaction">

              <div className="transaction-icon transfer">
                ↑
              </div>

              <div className="transaction-info">

                <strong>
                  Money Transfer
                </strong>

                <span>
                  07 Sep 2026
                </span>

              </div>

              <strong className="amount negative">
                -₹5,000
              </strong>

            </div>


            <div className="transaction">

              <div className="transaction-icon payment">
                💳
              </div>

              <div className="transaction-info">

                <strong>
                  Online Payment
                </strong>

                <span>
                  06 Sep 2026
                </span>

              </div>

              <strong className="amount negative">
                -₹2,000
              </strong>

            </div>

          </div>

        </section>


        {/* Fraud Detection */}
        <section
          className="fraud-card"
          id="fraud"
        >

          <div className="fraud-status">
            🛡️
          </div>

          <div>

            <h2>
              Fraud Detection Status
            </h2>

            <p>
              Your recent transactions were analyzed
              for suspicious activity.
            </p>

            <strong>
              ✓ LOW RISK
            </strong>

          </div>

          <div className="risk-score">

            <span>
              Risk Score
            </span>

            <strong>
              12/100
            </strong>

          </div>

        </section>

      </main>

    </div>
  );
}

export default Dashboard;