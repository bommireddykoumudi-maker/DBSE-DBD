import { Link } from "react-router-dom";

function FraudDetection() {
  return (
    <div className="fraud-page">

      <div className="fraud-container">

        <Link to="/dashboard" className="back-dashboard">
          ← Back to Dashboard
        </Link>

        <div className="fraud-page-header">
          <div className="fraud-page-icon">
            🛡️
          </div>

          <div>
            <h1>Fraud Detection</h1>
            <p>
              Monitor transactions and identify suspicious activity.
            </p>
          </div>
        </div>

        {/* Statistics */}

        <div className="fraud-stats">

          <div className="fraud-stat">
            <span>Transactions Analyzed</span>
            <strong>128</strong>
          </div>

          <div className="fraud-stat">
            <span>Suspicious Transactions</span>
            <strong>7</strong>
          </div>

          <div className="fraud-stat">
            <span>High Risk</span>
            <strong>2</strong>
          </div>

          <div className="fraud-stat">
            <span>Average Risk Score</span>
            <strong>18/100</strong>
          </div>

        </div>

        {/* Risk Table */}

        <div className="risk-table-card">

          <h2>Recent Risk Analysis</h2>

          <table>

            <thead>
              <tr>
                <th>Transaction</th>
                <th>Amount</th>
                <th>Risk Score</th>
                <th>Status</th>
              </tr>
            </thead>

            <tbody>

              <tr>
                <td>TXN001</td>
                <td>₹5,000</td>
                <td>12/100</td>
                <td>
                  <span className="risk-low">LOW</span>
                </td>
              </tr>

              <tr>
                <td>TXN002</td>
                <td>₹45,000</td>
                <td>78/100</td>
                <td>
                  <span className="risk-high">HIGH</span>
                </td>
              </tr>

              <tr>
                <td>TXN003</td>
                <td>₹2,500</td>
                <td>21/100</td>
                <td>
                  <span className="risk-low">LOW</span>
                </td>
              </tr>

              <tr>
                <td>TXN004</td>
                <td>₹30,000</td>
                <td>65/100</td>
                <td>
                  <span className="risk-review">REVIEW</span>
                </td>
              </tr>

            </tbody>

          </table>

        </div>

        {/* DBSCAN Feature */}

        <div className="dbscan-card">

          <div className="dbscan-icon">
            📊
          </div>

          <div>

            <h2>DBSCAN-Based Transaction Clustering</h2>

            <p>
              The proposed fraud detection module uses
              transaction behavior patterns to identify
              unusual transactions and potential anomalies.
            </p>

            <div className="cluster-display">

              <div>
                <span className="cluster-dot">●</span>
                Normal Transactions
              </div>

              <div>
                <span className="cluster-dot">●</span>
                Suspicious Transactions
              </div>

              <div>
                <span className="cluster-dot">●</span>
                Anomalies
              </div>

            </div>

          </div>

        </div>

      </div>

    </div>
  );
}

export default FraudDetection;