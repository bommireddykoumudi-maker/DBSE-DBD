import { BrowserRouter, Routes, Route, Link } from "react-router-dom";
import Login from "./pages/Login";
import Transfer from "./pages/Transfer";
import Register from "./pages/Register";
import "./App.css";
import Dashboard from "./pages/Dashboard";
import FraudDetection from "./pages/FraudDetection";
function Home() {
  return (
    <div className="app">

      {/* Navigation Bar */}
      <nav className="navbar">
        <div className="logo">
          🏦 EnterpriseBank
        </div>

        <div className="nav-links">
          <a href="#">Home</a>
          <a href="#">Services</a>
          <a href="#">About</a>

          <Link to="/login">
            <button className="login-btn">Login</button>
          </Link>

          <Link to="/register">
            <button className="signup-btn">Register</button>
          </Link>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="hero">
        <div className="hero-content">

          <h1>
            Secure. Smart.
            <br />
            Scalable Banking.
          </h1>

          <p>
            A modern banking platform built using
            microservices architecture for secure,
            reliable and scalable financial services.
          </p>

          <div className="hero-buttons">

            <Link to="/register">
              <button className="primary-btn">
                Get Started
              </button>
            </Link>

            <Link to="/login">
              <button className="secondary-btn">
                Login
              </button>
            </Link>

          </div>

        </div>
      </section>

      {/* Features */}
      <section className="features">

        <div className="feature-card">
          <div className="feature-icon">🔐</div>
          <h3>Secure</h3>
          <p>
            Secure authentication and protected
            banking operations.
          </p>
        </div>

        <div className="feature-card">
          <div className="feature-icon">⚡</div>
          <h3>Fast Transactions</h3>
          <p>
            Efficient processing of deposits,
            withdrawals and transfers.
          </p>
        </div>

        <div className="feature-card">
          <div className="feature-icon">📊</div>
          <h3>Scalable</h3>
          <p>
            Independent microservices that can
            scale according to demand.
          </p>
        </div>

      </section>

      {/* Fraud Detection */}
      <section className="fraud-section">

        <div className="fraud-icon">
          🛡️
        </div>

        <div>
          <h2>Intelligent Fraud Detection</h2>

          <p>
            Our proposed fraud detection service
            analyzes transaction behavior, identifies
            unusual patterns and generates risk scores
            for suspicious transactions.
          </p>
        </div>

      </section>

      {/* Footer */}
      <footer>
        <p>
          © 2026 EnterpriseBank | Enterprise Banking Microservices
        </p>
      </footer>

    </div>
  );
}

function App() {
  return (
    <BrowserRouter>

      <Routes>

        <Route path="/" element={<Home />} />

        <Route path="/login" element={<Login />} />

        <Route path="/register" element={<Register />} />
      
      <Route path="/dashboard" element={<Dashboard />} />
      
      <Route path="/transfer" element={<Transfer />} />
      
      <Route path="/fraud-detection" element={<FraudDetection />} />
      </Routes>

    </BrowserRouter>
  );
}

export default App;